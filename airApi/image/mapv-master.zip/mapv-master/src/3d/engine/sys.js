const conf = {
    longitudeLatitudeScale: 100
}

export default conf;