/**
 * @author kyle / http://nikai.us/
 */

/**
 * Canvas class
 */
function Canvas(el, options) {

    var el = document.getElementById(el);

}

export default Canvas;
