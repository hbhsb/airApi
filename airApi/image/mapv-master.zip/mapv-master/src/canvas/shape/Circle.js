/**
 * @author kyle / http://nikai.us/
 */

/**
 * Circle class
 */
function Circle() {
}

export default Circle;
