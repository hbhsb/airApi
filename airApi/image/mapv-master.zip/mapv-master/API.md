# 类参考文档

数据集对象
* [DataSet](https://github.com/huiyan-fe/mapv/blob/master/src/data/DataSet.md)

百度地图图层插件
* [baiduMapLayer](https://github.com/huiyan-fe/mapv/blob/master/src/map/baidu-map/Layer.md)

渐变色值域控制类
* [utilDataRangeIntensity](https://github.com/huiyan-fe/mapv/blob/master/src/utils/data-range/Intensity.md)
