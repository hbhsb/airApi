# 在node环境中使用mapv

## 依赖node-canvas
